distance module
===============

.. toctree::
   :maxdepth: 2

.. automodule:: bregman.distance
   :members:
