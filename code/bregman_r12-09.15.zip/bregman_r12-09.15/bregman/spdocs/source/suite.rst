bregman module
==============

.. toctree::
   :maxdepth: 2

.. automodule:: suite
   members:




