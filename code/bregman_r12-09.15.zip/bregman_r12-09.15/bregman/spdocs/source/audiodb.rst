audiodb module
==============

.. toctree::
   :maxdepth: 2

.. automodule:: bregman.audiodb
   :members:
