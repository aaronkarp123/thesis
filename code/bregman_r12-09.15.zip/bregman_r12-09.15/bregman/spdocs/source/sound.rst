sound module
============

.. toctree::
   :maxdepth: 2

.. automodule:: bregman.sound
   :members:
