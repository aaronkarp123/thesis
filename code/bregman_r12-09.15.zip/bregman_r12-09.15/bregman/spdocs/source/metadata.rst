metadata module
===============

.. toctree::
   :maxdepth: 2

.. automodule:: bregman.metadata
   :members:
